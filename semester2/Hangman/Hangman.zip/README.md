# Hangman
The popular game Hangman implemented in Java and Python.  

## Play
Please make sure you are using a command line interface that can read ANSI escape sequences.  

To compile and run the Java implementation  
```
javac Hangman.java  
java Hangman  
```

To run the Python implementation  
```
python Hangman.py  
```

## Fun Fact
This was all coded using only Vim. It was a major pain.
