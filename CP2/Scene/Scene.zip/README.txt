artwork.mp4 is a very real video of my mom reacting to my artwork while it is on the fridge.
